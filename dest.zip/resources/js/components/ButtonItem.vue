<template>
    <el-row>
        <el-button>登録</el-button>
    </el-row>
</template>

