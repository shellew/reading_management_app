<?php $__env->startSection('content'); ?>
    
    <div id="app">
        <div class="container">
            <scafold></scafold>
        </div>
    </div>

    <!-- Vueを読み込む -->
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/app.blade.php ENDPATH**/ ?>